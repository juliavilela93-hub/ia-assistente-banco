# 02 - Base de Conhecimento

## Dados Utilizados

Os dados utilizados ficam na pasta `data/` e são mockados, ou seja, foram criados apenas para fins de teste e aprendizado.

| Arquivo | Formato | Utilização no Agente |
|---|---|---|
| historico_atendimento.csv | CSV | Contextualizar interações anteriores |
| perfil_investidor.json | JSON | Personalizar recomendações |
| produtos_financeiros.json | JSON | Sugerir produtos adequados ao perfil |
| transacoes.csv | CSV | Analisar padrão de gastos do cliente |

---

## Descrição dos Arquivos

### transacoes.csv

Contém o histórico financeiro do cliente, com receitas e saídas.

Campos principais:

- data;
- descrição;
- categoria;
- valor;
- tipo.

Exemplo de uso:

O agente pode responder perguntas como:

- "Quanto gastei com alimentação?"
- "Qual foi minha maior despesa?"
- "Qual categoria teve mais gastos?"

---

### perfil_investidor.json

Contém informações gerais sobre o perfil financeiro do cliente.

Campos principais:

- nome;
- idade;
- profissão;
- renda mensal;
- perfil investidor;
- objetivo principal;
- metas;
- tolerância a risco.

Exemplo de uso:

O agente pode identificar que o cliente possui perfil moderado, mas não aceita risco alto. Por isso, deve priorizar recomendações conservadoras ou de baixo risco.

---

### produtos_financeiros.json

Contém uma lista de produtos financeiros disponíveis.

Campos principais:

- nome;
- categoria;
- risco;
- rentabilidade;
- aporte mínimo;
- indicação.

Exemplo de uso:

O agente pode sugerir produtos de baixo risco para reserva de emergência, como Tesouro Selic ou CDB de Liquidez Diária.

---

### historico_atendimento.csv

Contém interações anteriores do cliente.

Campos principais:

- data;
- canal;
- tema;
- resumo;
- resolvido.

Exemplo de uso:

O agente pode entender que o cliente já perguntou anteriormente sobre CDB, Tesouro Selic e metas financeiras.

---

## Adaptações nos Dados

Os dados foram mantidos simples para facilitar o entendimento do projeto.

A base representa um cliente fictício chamado João Silva, com renda mensal de R$ 5.000, perfil moderado e objetivo principal de construir uma reserva de emergência.

---

## Estratégia de Integração

### Como os dados são carregados?

Os dados CSV e JSON são carregados no início da execução da aplicação Python.

### Como os dados são usados no prompt?

A aplicação consulta os dados e monta respostas com base nas informações encontradas.

### Os dados vão no system prompt?

Neste protótipo simples, os dados não são enviados para um modelo externo. A aplicação simula o comportamento de um assistente usando regras, leitura de arquivos e respostas controladas.

---

## Exemplo de Contexto Montado

```text
Dados do Cliente:
- Nome: João Silva
- Perfil: Moderado
- Renda mensal: R$ 5.000
- Objetivo principal: Construir reserva de emergência
- Reserva atual: R$ 10.000
- Meta de reserva: R$ 15.000

Últimas transações:
- Aluguel: R$ 1.200
- Supermercado: R$ 450
- Restaurante: R$ 120
- Combustível: R$ 250

Produtos disponíveis:
- Tesouro Selic
- CDB Liquidez Diária
- LCI/LCA
- Fundo Multimercado
- Fundo de Ações
```
