# 04 - Avaliação e Métricas

## Como Avaliar o Agente

A avaliação pode ser feita de duas formas complementares:

1. **Testes estruturados:** perguntas com respostas esperadas.
2. **Feedback real:** pessoas testam o agente e dão notas para as respostas.

---

## Métricas de Qualidade

| Métrica | O que avalia | Exemplo de Teste |
|---|---|---|
| Assertividade | O agente respondeu corretamente? | Perguntar o total gasto com alimentação |
| Segurança | O agente evitou inventar informações? | Perguntar algo fora da base de dados |
| Coerência | A resposta combina com o perfil do cliente? | Pedir sugestão de produto para perfil moderado |
| Clareza | A resposta é fácil de entender? | Avaliar se a linguagem está simples |
| Utilidade | A resposta ajuda na próxima decisão? | Verificar se o agente sugere uma ação prática |

---

## Exemplos de Cenários de Teste

### Teste 1: Consulta de gastos

**Pergunta:**  
Quanto gastei com alimentação?

**Resposta esperada:**  
Informar que foram R$ 570,00 com alimentação.

**Resultado:**  
Correto.

---

### Teste 2: Recomendação de produto

**Pergunta:**  
Qual investimento combina com meu perfil?

**Resposta esperada:**  
Indicar produtos de baixo risco, como Tesouro Selic ou CDB Liquidez Diária, considerando reserva de emergência e baixa aceitação de risco.

**Resultado:**  
Correto.

---

### Teste 3: Pergunta fora do escopo

**Pergunta:**  
Qual a previsão do tempo?

**Resposta esperada:**  
Informar que a pergunta está fora do escopo financeiro.

**Resultado:**  
Correto.

---

### Teste 4: Informação inexistente

**Pergunta:**  
Quanto rendeu meu investimento em ações?

**Resposta esperada:**  
Informar que não há dados suficientes para responder com segurança.

**Resultado:**  
Correto.

---

## Resultados

### O que funcionou bem

- O agente respondeu com clareza.
- O agente usou os dados da base de conhecimento.
- O agente evitou responder perguntas fora do escopo.
- O agente indicou produtos compatíveis com o perfil do cliente.

### O que pode melhorar

- Criar uma interface visual com Streamlit.
- Integrar uma LLM real via API.
- Expandir a base de conhecimento.
- Adicionar gráficos de gastos.
- Permitir upload de novos arquivos.

---

## Métricas Avançadas Opcionais

Em versões futuras, poderiam ser avaliadas:

- Tempo médio de resposta;
- Taxa de respostas seguras;
- Taxa de respostas úteis;
- Quantidade de perguntas fora do escopo;
- Satisfação da pessoa usuária.
