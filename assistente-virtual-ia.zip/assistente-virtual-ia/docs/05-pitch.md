# 05 - Pitch

## Pitch de 3 minutos

### 1. O Problema

Muitas pessoas que estão começando a organizar sua vida financeira têm dificuldade para entender seus gastos, criar metas e escolher produtos financeiros simples.

Além disso, conteúdos sobre finanças muitas vezes são complexos, técnicos ou genéricos, o que dificulta a tomada de decisão.

---

### 2. A Solução

O **IA Assistente Banco** é um assistente virtual com Inteligência Artificial criado para apoiar pessoas iniciantes em finanças.

Ele conversa com a pessoa usuária, entende dúvidas simples e responde com base em uma base de conhecimento organizada.

O assistente pode ajudar a identificar gastos por categoria, sugerir próximos passos para economizar, explicar produtos financeiros básicos e apoiar a criação de uma reserva de emergência.

---

### 3. Demonstração

Na prática, a pessoa pode perguntar:

```text
Quanto gastei com alimentação?
```

O assistente consulta as transações disponíveis e responde que o total foi de R$ 570,00, considerando supermercado e restaurante.

Outro exemplo:

```text
Qual produto financeiro combina com meu perfil?
```

O assistente analisa o perfil moderado do cliente, o objetivo de construir reserva de emergência e a baixa aceitação a risco. Com isso, sugere produtos de baixo risco, como Tesouro Selic ou CDB de Liquidez Diária.

---

### 4. Diferencial e Impacto

O diferencial do IA Assistente Banco é combinar simplicidade, personalização e segurança.

Ele não apenas responde perguntas genéricas, mas utiliza dados organizados para entregar uma resposta mais contextualizada.

Além disso, o projeto considera boas práticas de segurança, evitando respostas inventadas e informando quando não há dados suficientes.

Essa solução pode ajudar pessoas iniciantes a tomar decisões financeiras mais conscientes, reduzir dúvidas básicas e melhorar sua organização financeira.

---

## Checklist do Pitch

- [x] Duração máxima de 3 minutos
- [x] Problema claramente definido
- [x] Solução demonstrada na prática
- [x] Diferencial explicado
- [x] Áudio e vídeo com boa qualidade

---

## Link do Vídeo

```text
Cole aqui o link do seu pitch depois de gravar.
```
