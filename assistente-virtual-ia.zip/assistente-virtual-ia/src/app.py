import csv
import json
from pathlib import Path
from collections import defaultdict

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"


def carregar_transacoes():
    caminho = DATA_DIR / "transacoes.csv"
    with open(caminho, encoding="utf-8") as arquivo:
        return list(csv.DictReader(arquivo))


def carregar_json(nome_arquivo):
    caminho = DATA_DIR / nome_arquivo
    with open(caminho, encoding="utf-8") as arquivo:
        return json.load(arquivo)


def formatar_moeda(valor):
    return f"R$ {float(valor):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def total_por_categoria(transacoes, categoria):
    total = 0
    itens = []

    for item in transacoes:
        if item["tipo"] == "saida" and item["categoria"].lower() == categoria.lower():
            valor = float(item["valor"])
            total += valor
            itens.append((item["descricao"], valor))

    return total, itens


def maior_categoria_gasto(transacoes):
    gastos = defaultdict(float)

    for item in transacoes:
        if item["tipo"] == "saida":
            gastos[item["categoria"]] += float(item["valor"])

    if not gastos:
        return None, 0

    categoria = max(gastos, key=gastos.get)
    return categoria, gastos[categoria]


def recomendar_produto(perfil, produtos):
    perfil_investidor = perfil.get("perfil_investidor", "").lower()
    aceita_risco = perfil.get("aceita_risco", False)
    objetivo = perfil.get("objetivo_principal", "").lower()

    recomendados = []

    for produto in produtos:
        risco = produto["risco"].lower()
        indicado = produto["indicado_para"].lower()

        if "reserva" in objetivo and risco == "baixo":
            recomendados.append(produto)
        elif perfil_investidor == "moderado" and risco in ["baixo", "medio"] and aceita_risco:
            recomendados.append(produto)
        elif perfil_investidor == "moderado" and not aceita_risco and risco == "baixo":
            recomendados.append(produto)

    return recomendados[:2]


def responder(pergunta, transacoes, perfil, produtos):
    pergunta = pergunta.lower().strip()

    if any(termo in pergunta for termo in ["senha", "token", "cartão completo", "numero do cartão", "número do cartão"]):
        return (
            "Não tenho acesso a senhas, tokens ou dados sensíveis. "
            "Posso ajudar apenas com informações financeiras seguras e disponíveis na base de conhecimento."
        )

    if any(termo in pergunta for termo in ["tempo", "clima", "previsão do tempo", "futebol", "receita de comida"]):
        return (
            "Minha especialidade é finanças pessoais. Não tenho informações suficientes para responder essa pergunta. "
            "Posso te ajudar com gastos, metas, reserva de emergência ou produtos financeiros básicos."
        )

    if "alimentação" in pergunta or "alimentacao" in pergunta:
        total, itens = total_por_categoria(transacoes, "alimentacao")
        detalhes = ", ".join([f"{nome}: {formatar_moeda(valor)}" for nome, valor in itens])
        return f"Com base nas transações disponíveis, você gastou {formatar_moeda(total)} com alimentação. Detalhes: {detalhes}."

    if "maior gasto" in pergunta or "maior categoria" in pergunta or "mais gastei" in pergunta:
        categoria, valor = maior_categoria_gasto(transacoes)
        return f"Sua maior categoria de gasto foi {categoria}, com total de {formatar_moeda(valor)}."

    if "reserva" in pergunta or "emergência" in pergunta or "emergencia" in pergunta:
        atual = perfil["reserva_emergencia_atual"]
        meta = 15000.00
        falta = meta - atual
        return (
            f"Sua reserva de emergência atual é de {formatar_moeda(atual)}. "
            f"A meta cadastrada é {formatar_moeda(meta)}. "
            f"Faltam {formatar_moeda(falta)} para completar essa meta. "
            "Uma próxima ação seria separar um valor mensal fixo para acelerar esse objetivo."
        )

    if "produto" in pergunta or "investimento" in pergunta or "investir" in pergunta or "perfil" in pergunta:
        recomendados = recomendar_produto(perfil, produtos)
        if not recomendados:
            return "Não encontrei um produto compatível com os dados disponíveis para responder com segurança."

        nomes = " e ".join([produto["nome"] for produto in recomendados])
        return (
            f"Com base no seu perfil {perfil['perfil_investidor']} e no objetivo de {perfil['objetivo_principal'].lower()}, "
            f"uma opção adequada pode ser {nomes}. Esses produtos aparecem na base como alternativas compatíveis para reserva de emergência ou perfil iniciante."
        )

    if "renda" in pergunta or "salário" in pergunta or "salario" in pergunta:
        return f"A renda mensal cadastrada na base de conhecimento é {formatar_moeda(perfil['renda_mensal'])}."

    if "ações" in pergunta or "acoes" in pergunta or "rendeu" in pergunta or "rentabilidade passada" in pergunta:
        return (
            "Não encontrei informações suficientes na base de conhecimento para responder com segurança. "
            "Os dados disponíveis não mostram rendimento mensal de ações ou rentabilidade passada da carteira."
        )

    return (
        "Não encontrei informação suficiente na base de conhecimento para responder com segurança. "
        "Posso ajudar com perguntas sobre gastos, alimentação, maior categoria de gasto, reserva de emergência ou produtos financeiros básicos."
    )


def main():
    transacoes = carregar_transacoes()
    perfil = carregar_json("perfil_investidor.json")
    produtos = carregar_json("produtos_financeiros.json")

    print("=" * 60)
    print("IA ASSISTENTE BANCO")
    print("Assistente financeiro para pessoas iniciantes em finanças")
    print("=" * 60)
    print("Digite sua pergunta ou escreva 'sair' para encerrar.")
    print("Exemplos:")
    print("- Quanto gastei com alimentação?")
    print("- Qual minha maior categoria de gasto?")
    print("- Como está minha reserva de emergência?")
    print("- Qual produto financeiro combina com meu perfil?")
    print("=" * 60)

    while True:
        pergunta = input("\nVocê: ")

        if pergunta.lower().strip() in ["sair", "exit", "quit"]:
            print("IA Assistente Banco: Até mais! Continue acompanhando sua vida financeira.")
            break

        resposta = responder(pergunta, transacoes, perfil, produtos)
        print(f"IA Assistente Banco: {resposta}")


if __name__ == "__main__":
    main()
