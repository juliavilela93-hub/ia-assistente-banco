# IA Assistente Banco

## Visão Geral

O **IA Assistente Banco** é um protótipo de assistente virtual com Inteligência Artificial voltado para pessoas iniciantes em finanças.

A proposta é criar uma solução simples, capaz de conversar com uma pessoa usuária, entender uma necessidade financeira básica e responder com base em informações organizadas em uma base de conhecimento.

O projeto foi desenvolvido como parte do desafio **"Construa Seu Assistente Virtual Com Inteligência Artificial"**.

---

## Problema

Muitas pessoas que estão começando a organizar a vida financeira têm dificuldade para entender seus gastos, montar uma reserva de emergência, escolher produtos financeiros simples e tomar uma próxima decisão com segurança.

Além disso, é comum que uma pessoa iniciante receba informações genéricas ou complexas demais, o que pode gerar confusão.

---

## Solução

O **IA Assistente Banco** ajuda a pessoa usuária a:

- Entender gastos mensais;
- Identificar categorias com maior despesa;
- Receber sugestões simples de organização financeira;
- Conhecer produtos financeiros básicos;
- Verificar se uma recomendação combina com seu perfil;
- Receber respostas seguras, sem informações inventadas.

---

## Público-alvo

Pessoas iniciantes em finanças, que desejam organizar melhor seus gastos, criar uma reserva de emergência e entender opções financeiras simples.

---

## Estrutura do Repositório

```text
assistente-virtual-ia/
│
├── README.md
│
├── data/
│   ├── historico_atendimento.csv
│   ├── perfil_investidor.json
│   ├── produtos_financeiros.json
│   └── transacoes.csv
│
├── docs/
│   ├── 01-documentacao-agente.md
│   ├── 02-base-conhecimento.md
│   ├── 03-prompts.md
│   ├── 04-metricas.md
│   └── 05-pitch.md
│
├── src/
│   └── app.py
│
└── assets/
```

---

## Como Executar o Projeto

1. Baixe ou clone este repositório.
2. Abra a pasta do projeto.
3. Execute o arquivo principal:

```bash
python src/app.py
```

---

## Exemplos de Perguntas

```text
Quanto gastei com alimentação?
```

```text
Qual produto financeiro combina com meu perfil?
```

```text
Como posso montar uma reserva de emergência?
```

```text
Qual minha maior categoria de gasto?
```

```text
Qual a previsão do tempo para amanhã?
```

Nesse último caso, o agente deve informar que a pergunta está fora do escopo financeiro.

---

## Tecnologias Utilizadas

- Python
- CSV
- JSON
- Markdown
- Lógica simples de busca e resposta
- Base de conhecimento mockada

---

## Segurança e Anti-Alucinação

O assistente foi planejado para responder apenas com base nos dados disponíveis nos arquivos da pasta `data/`.

Quando não possui informação suficiente, ele informa que não consegue responder com segurança, evitando inventar dados.

---

## Resultado Esperado

Ao final, o projeto demonstra como a Inteligência Artificial pode apoiar uma pessoa iniciante em finanças, oferecendo respostas simples, úteis e baseadas em dados organizados.
